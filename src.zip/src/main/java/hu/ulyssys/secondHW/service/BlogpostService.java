package hu.ulyssys.secondHW.service;

import hu.ulyssys.secondHW.entity.Blogpost;

public interface BlogpostService extends CoreWebblogService<Blogpost>{
}
