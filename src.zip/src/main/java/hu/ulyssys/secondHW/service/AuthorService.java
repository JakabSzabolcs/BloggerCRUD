package hu.ulyssys.secondHW.service;

import hu.ulyssys.secondHW.entity.Author;

public interface AuthorService extends CoreWebblogService<Author> {
}
