package hu.ulyssys.secondHW.DAO;

import hu.ulyssys.secondHW.entity.AbstractWebblog;
import hu.ulyssys.secondHW.entity.Blogpost;

public interface BlogpostDAO extends CoreWebblogDAO<Blogpost> {
}
