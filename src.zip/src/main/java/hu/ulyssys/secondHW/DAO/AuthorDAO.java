package hu.ulyssys.secondHW.DAO;

import hu.ulyssys.secondHW.entity.Author;

public interface AuthorDAO extends CoreWebblogDAO<Author> {
}
