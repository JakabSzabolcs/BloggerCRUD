package hu.ulyssys.secondHW.mbean;


import hu.ulyssys.secondHW.entity.Author;
import hu.ulyssys.secondHW.service.AuthorService;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Named
@ViewScoped
public class AuthorMBean extends CoreMBean<Author>
{

}
